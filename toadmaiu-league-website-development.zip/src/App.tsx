import Nav from "./components/Nav";
import Hero from "./components/Hero";
import Marquee from "./components/Marquee";
import Standings from "./components/Standings";
import Rosters from "./components/Rosters";
import Cup from "./components/Cup";
import Games from "./components/Games";
import Rules from "./components/Rules";
import Footer from "./components/Footer";

export default function App() {
  return (
    <div className="min-h-screen overflow-x-clip bg-void font-body text-mist antialiased">
      <div className="noise-overlay" aria-hidden="true" />
      <Nav />
      <main>
        <Hero />
        <Marquee />
        <Standings />
        <Rosters />
        <Cup />
        <Games />
        <Rules />
      </main>
      <Footer />
    </div>
  );
}
