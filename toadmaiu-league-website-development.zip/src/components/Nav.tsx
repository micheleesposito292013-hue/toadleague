import { useEffect, useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Menu, X } from "lucide-react";

const LINKS = [
  { label: "Classifica", href: "#classifica" },
  { label: "Team", href: "#rose" },
  { label: "La Coppa", href: "#coppa" },
  { label: "Giochi", href: "#giochi" },
  { label: "Regolamento", href: "#regolamento" },
];

function ToadMark({ className }: { className?: string }) {
  return (
    <svg viewBox="0 0 32 32" className={className} aria-hidden="true">
      <rect width="32" height="32" rx="8" fill="#a3e635" />
      <circle cx="11" cy="13" r="4" fill="#070a07" />
      <circle cx="21" cy="13" r="4" fill="#070a07" />
      <circle cx="11" cy="12.4" r="1.4" fill="#e9f5df" />
      <circle cx="21" cy="12.4" r="1.4" fill="#e9f5df" />
      <path
        d="M10 22q6 4 12 0"
        stroke="#070a07"
        strokeWidth="2.2"
        fill="none"
        strokeLinecap="round"
      />
    </svg>
  );
}

export default function Nav() {
  const [scrolled, setScrolled] = useState(false);
  const [open, setOpen] = useState(false);

  useEffect(() => {
    const onScroll = () => setScrolled(window.scrollY > 24);
    onScroll();
    window.addEventListener("scroll", onScroll, { passive: true });
    return () => window.removeEventListener("scroll", onScroll);
  }, []);

  return (
    <header
      className={`fixed inset-x-0 top-0 z-50 transition-all duration-500 ${
        scrolled
          ? "border-b border-white/5 bg-void/80 backdrop-blur-xl"
          : "border-b border-transparent bg-transparent"
      }`}
    >
      <nav className="mx-auto flex h-[72px] max-w-7xl items-center justify-between px-6">
        <a href="#top" className="group flex items-center gap-3">
          <ToadMark className="h-9 w-9 transition-transform duration-500 group-hover:rotate-6" />
          <span className="font-display text-[13px] font-bold uppercase tracking-[0.18em]">
            Toadmaiu <span className="text-toad">League</span>
          </span>
        </a>

        <div className="hidden items-center gap-7 lg:flex">
          {LINKS.map((l) => (
            <a
              key={l.href}
              href={l.href}
              className="group relative text-[13px] font-medium uppercase tracking-[0.14em] text-white/60 transition-colors hover:text-mist"
            >
              {l.label}
              <span className="absolute -bottom-1.5 left-0 h-px w-0 bg-toad transition-all duration-300 group-hover:w-full" />
            </a>
          ))}
          <a
            href="#classifica"
            className="rounded-full bg-toad px-5 py-2.5 text-[12px] font-bold uppercase tracking-[0.14em] text-void transition-all duration-300 hover:shadow-[0_0_30px_rgba(163,230,53,0.45)]"
          >
            Season 4
          </a>
        </div>

        <button
          onClick={() => setOpen((v) => !v)}
          className="flex h-10 w-10 items-center justify-center rounded-full border border-white/10 text-mist lg:hidden"
          aria-label="Menu"
        >
          {open ? <X className="h-5 w-5" /> : <Menu className="h-5 w-5" />}
        </button>
      </nav>

      <AnimatePresence>
        {open && (
          <motion.div
            initial={{ opacity: 0, height: 0 }}
            animate={{ opacity: 1, height: "auto" }}
            exit={{ opacity: 0, height: 0 }}
            transition={{ duration: 0.35, ease: [0.22, 1, 0.36, 1] }}
            className="overflow-hidden border-b border-white/5 bg-void/95 backdrop-blur-xl lg:hidden"
          >
            <div className="flex flex-col gap-1 px-6 py-6">
              {LINKS.map((l) => (
                <a
                  key={l.href}
                  href={l.href}
                  onClick={() => setOpen(false)}
                  className="rounded-xl px-4 py-3 font-display text-sm font-semibold uppercase tracking-[0.14em] text-white/70 transition-colors hover:bg-white/5 hover:text-toad"
                >
                  {l.label}
                </a>
              ))}
            </div>
          </motion.div>
        )}
      </AnimatePresence>
    </header>
  );
}
