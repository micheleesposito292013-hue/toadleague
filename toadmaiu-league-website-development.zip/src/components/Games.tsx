import { motion } from "framer-motion";
import { Gamepad2 } from "lucide-react";
import { TIERS } from "../data/league";

export default function Games() {
  return (
    <section id="giochi" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/2 top-0 h-[300px] w-[600px] -translate-x-1/2 rounded-full bg-toad/5 blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-14 text-center"
        >
          <p className="inline-flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-toad">
            <span className="h-px w-10 bg-toad/60" />
            <Gamepad2 className="h-4 w-4" />
            <span className="h-px w-10 bg-toad/60" />
          </p>
          <h2 className="mt-4 font-display text-4xl font-black uppercase leading-none tracking-tight sm:text-6xl">
            I Giochi
          </h2>
          <p className="mx-auto mt-5 max-w-lg text-sm leading-relaxed text-white/40">
            I titoli validi per i tornei della League, in ordine di
            importanza: dai main event ai giochi di terzo posto.
          </p>
        </motion.div>

        <div className="grid gap-5 md:grid-cols-3">
          {TIERS.map((t, i) => (
            <motion.div
              key={t.rank}
              initial={{ opacity: 0, y: 40 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-60px" }}
              transition={{
                delay: i * 0.12,
                duration: 0.8,
                ease: [0.22, 1, 0.36, 1],
              }}
              className={`group relative overflow-hidden rounded-3xl border p-7 transition-all duration-500 sm:p-8 ${
                t.featured
                  ? "border-toad/30 bg-gradient-to-b from-toad/[0.08] to-transparent shadow-[0_0_60px_-20px_rgba(163,230,53,0.35)]"
                  : "border-white/8 bg-white/[0.02] hover:border-white/20"
              }`}
            >
              {t.featured && (
                <span className="absolute right-6 top-6 rounded-full bg-toad px-3 py-1 text-[9px] font-bold uppercase tracking-[0.18em] text-void">
                  Main
                </span>
              )}

              <p
                className={`font-display text-6xl font-black leading-none ${
                  t.featured ? "text-outline-toad" : "text-outline"
                }`}
              >
                {t.rank}
              </p>
              <h3 className="mt-5 font-display text-lg font-bold uppercase tracking-wide text-mist">
                {t.name}
              </h3>
              <p className="mt-1 text-[10px] font-bold uppercase tracking-[0.22em] text-toad/80">
                {t.badge}
              </p>

              <div className="mt-6 flex flex-wrap gap-2">
                {t.games.map((g) => (
                  <span
                    key={g}
                    className={`rounded-full border px-3.5 py-1.5 text-xs font-medium transition-colors duration-300 ${
                      t.featured
                        ? "border-toad/30 bg-toad/10 text-toad"
                        : "border-white/10 bg-white/[0.04] text-white/60 group-hover:border-white/25 group-hover:text-mist"
                    }`}
                  >
                    {g}
                  </span>
                ))}
              </div>

              <p className="mt-6 text-xs leading-relaxed text-white/35">
                {t.note}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
