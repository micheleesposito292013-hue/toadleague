import { ArrowUp, ArrowUpRight, CalendarDays, Globe } from "lucide-react";
import { SEASON } from "../data/league";

const DOMAIN = "toadmaiuleague.com";
const DOMAIN_URL = `https://${DOMAIN}`;

export default function Footer() {
  return (
    <footer className="relative overflow-hidden border-t border-white/5">
      <div className="relative mx-auto max-w-7xl px-6 pb-10 pt-16">
        <div className="flex flex-col items-start justify-between gap-10 md:flex-row md:items-end">
          <div>
            <p className="flex items-center gap-2.5 text-[11px] font-bold uppercase tracking-[0.3em] text-toad">
              <CalendarDays className="h-3.5 w-3.5" />
              Season {SEASON.number} · {SEASON.start} → {SEASON.end}
            </p>
            <p className="mt-5 max-w-md text-sm leading-relaxed text-white/40">
              La competizione ufficiale del canale di{" "}
              <span className="font-semibold text-mist">
                Samuele Maiuri
              </span>
              , in arte <span className="font-semibold text-toad">Toadmaiu</span>
              . Sei team, tornei in live e un solo trono.
            </p>

            <a
              href={DOMAIN_URL}
              target="_blank"
              rel="noopener noreferrer"
              className="group mt-7 inline-flex items-center gap-3 rounded-full border border-toad/30 bg-toad/5 px-5 py-3 transition-all duration-300 hover:border-toad/60 hover:bg-toad/10 hover:shadow-[0_0_30px_-6px_rgba(163,230,53,0.5)]"
            >
              <Globe className="h-4 w-4 text-toad" />
              <span className="font-display text-[13px] font-bold tracking-[0.08em] text-mist">
                {DOMAIN}
              </span>
              <ArrowUpRight className="h-4 w-4 text-toad transition-transform duration-300 group-hover:translate-x-0.5 group-hover:-translate-y-0.5" />
            </a>
          </div>

          <a
            href="#top"
            className="group inline-flex items-center gap-3 rounded-full border border-white/15 px-6 py-3 text-[11px] font-bold uppercase tracking-[0.18em] text-mist transition-all duration-300 hover:border-toad/50 hover:text-toad"
          >
            Torna su
            <ArrowUp className="h-4 w-4 transition-transform duration-300 group-hover:-translate-y-1" />
          </a>
        </div>

        <p className="text-outline mt-14 select-none whitespace-nowrap font-display text-[11.5vw] font-black uppercase leading-[0.9] tracking-tight">
          Toadmaiu League
        </p>

        <div className="mt-10 flex flex-col items-start justify-between gap-3 border-t border-white/5 pt-6 text-[11px] font-medium uppercase tracking-[0.18em] text-white/25 sm:flex-row sm:items-center">
          <p>© 2026 Toadmaiu League</p>
          <p>
            Season {SEASON.number} · {SEASON.start} — {SEASON.end}
          </p>
        </div>
      </div>
    </footer>
  );
}
