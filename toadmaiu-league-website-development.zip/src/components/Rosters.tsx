import { useState } from "react";
import { AnimatePresence, motion } from "framer-motion";
import { Crown, Info, Trophy } from "lucide-react";
import { ROSTERS, STANDINGS, ZONES } from "../data/league";

const EASE = [0.22, 1, 0.36, 1] as const;

export default function Rosters() {
  const [active, setActive] = useState(STANDINGS[0].team);
  const team = STANDINGS.find((t) => t.team === active) ?? STANDINGS[0];
  const zone = ZONES[team.zone];
  const players = ROSTERS[team.team] ?? [];

  return (
    <section id="rose" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-1/4 top-0 h-[360px] w-[480px] -translate-x-1/2 rounded-full bg-violet-500/5 blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* header */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: EASE }}
          className="mb-14 flex flex-col gap-6 md:flex-row md:items-end md:justify-between"
        >
          <div>
            <p className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-toad">
              <span className="h-px w-10 bg-toad/60" />
              Le rose · max 8 giocatori
            </p>
            <h2 className="mt-4 font-display text-4xl font-black uppercase leading-none tracking-tight sm:text-6xl">
              I Team
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-white/40">
            Le rose complete della Season 4. Scegli un team per vederne la
            rosa — a capo di ogni squadra c'è un capitano.
          </p>
        </motion.div>

        <div className="grid gap-6 lg:grid-cols-[320px_1fr]">
          {/* rail */}
          <div className="flex snap-x gap-3 overflow-x-auto pb-2 lg:sticky lg:top-24 lg:h-fit lg:flex-col lg:overflow-visible lg:pb-0">
            {STANDINGS.map((s, i) => {
              const isActive = active === s.team;
              return (
                <motion.button
                  key={s.team}
                  onClick={() => setActive(s.team)}
                  initial={{ opacity: 0, x: -20 }}
                  whileInView={{ opacity: 1, x: 0 }}
                  viewport={{ once: true }}
                  transition={{ delay: i * 0.06, duration: 0.5, ease: EASE }}
                  aria-pressed={isActive}
                  className={`flex w-[240px] shrink-0 snap-start items-center gap-3 rounded-2xl border px-4 py-3.5 text-left transition-all duration-300 lg:w-full ${
                    isActive
                      ? "border-toad/50 bg-toad/10 shadow-[0_0_36px_-12px_rgba(163,230,53,0.6)]"
                      : "border-white/8 bg-white/[0.02] hover:border-white/20 hover:bg-white/[0.04]"
                  }`}
                >
                  <span
                    className={`font-display text-sm font-extrabold tabular-nums ${
                      isActive ? "text-toad" : "text-white/30"
                    }`}
                  >
                    {s.rank}
                  </span>
                  <img
                    src={s.badge}
                    alt={s.team}
                    className="h-8 w-8 shrink-0 rounded-md object-contain"
                  />
                  <span className="min-w-0 flex-1">
                    <span className="block truncate font-display text-[13px] font-bold uppercase tracking-wide text-mist">
                      {s.team}
                    </span>
                    <span className="mt-0.5 block text-[10px] font-semibold uppercase tracking-[0.16em] text-white/30">
                      {s.points} pt
                    </span>
                  </span>
                  {s.cup && (
                    <Trophy className="h-3.5 w-3.5 shrink-0 text-toad" />
                  )}
                </motion.button>
              );
            })}
          </div>

          {/* panel */}
          <AnimatePresence mode="wait">
            <motion.div
              key={team.team}
              initial={{ opacity: 0, y: 18 }}
              animate={{ opacity: 1, y: 0 }}
              exit={{ opacity: 0, y: -12 }}
              transition={{ duration: 0.4, ease: EASE }}
              className="relative overflow-hidden rounded-3xl border border-white/10 bg-panel/70 p-6 backdrop-blur-sm sm:p-9"
            >
              <div className="pointer-events-none absolute -right-20 -top-24 h-64 w-64 rounded-full bg-toad/8 blur-[90px]" />

              <div className="relative flex flex-wrap items-start justify-between gap-5 border-b border-white/6 pb-6">
                <div className="flex min-w-0 items-start gap-5">
                  <img
                    src={team.badge}
                    alt={`${team.team} badge`}
                    className="h-16 w-16 shrink-0 rounded-xl object-contain sm:h-20 sm:w-20"
                  />
                  <div className="min-w-0">
                    <div className="flex flex-wrap items-center gap-3">
                      <span
                        className={`h-2.5 w-2.5 rounded-full ${zone.dot} ${zone.glow}`}
                      />
                      <p className="text-[11px] font-bold uppercase tracking-[0.24em] text-toad">
                        {zone.label}
                      </p>
                      {team.cup && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-toad/30 bg-toad/10 px-2.5 py-0.5 text-[9px] font-bold uppercase tracking-[0.14em] text-toad">
                          <Trophy className="h-2.5 w-2.5" />
                          Coppa
                        </span>
                      )}
                    </div>
                    <h3 className="mt-3 font-display text-[clamp(1.7rem,4vw,3rem)] font-black uppercase leading-none tracking-tight text-mist">
                      {team.team}
                    </h3>
                    <p className="mt-3 text-sm text-white/40">
                      {players.length} giocatori in rosa ·{" "}
                      <span className="text-toad">
                        {players.length} di 8 slot
                      </span>
                    </p>
                  </div>
                </div>

                <div className="rounded-2xl border border-white/10 bg-white/[0.03] px-6 py-4 text-right">
                  <p className="font-display text-3xl font-bold text-toad">
                    {team.points}
                    <span className="ml-1 text-xs font-semibold text-white/30">
                      pt
                    </span>
                  </p>
                  <p className="mt-1 text-[10px] font-semibold uppercase tracking-[0.16em] text-white/30">
                    Posizione {team.rank}°
                  </p>
                </div>
              </div>

              {players.length > 0 ? (
                <motion.ul
                  initial="hidden"
                  animate="show"
                  variants={{
                    hidden: {},
                    show: { transition: { staggerChildren: 0.05 } },
                  }}
                  className="relative mt-6 grid gap-3 sm:grid-cols-2"
                >
                  {players.map((p, i) => (
                    <motion.li
                      key={p}
                      variants={{
                        hidden: { opacity: 0, x: -16 },
                        show: {
                          opacity: 1,
                          x: 0,
                          transition: { duration: 0.5, ease: EASE },
                        },
                      }}
                      className="group flex items-center gap-4 rounded-2xl border border-white/8 bg-white/[0.02] px-5 py-4 transition-all duration-300 hover:border-toad/30 hover:bg-toad/[0.06]"
                    >
                      <span className="font-display text-[11px] font-bold tabular-nums text-toad/50">
                        {String(i + 1).padStart(2, "0")}
                      </span>
                      <span className="min-w-0 flex-1 truncate font-display text-[13px] font-semibold uppercase tracking-wide text-mist transition-colors duration-300 group-hover:text-toad">
                        {p}
                      </span>
                      {p.toLowerCase() === "toadmaiu" && (
                        <span className="inline-flex shrink-0 items-center gap-1 rounded-full border border-yellow-400/30 bg-yellow-400/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.14em] text-yellow-300">
                          <Crown className="h-2.5 w-2.5" />
                          Fondatore
                        </span>
                      )}
                    </motion.li>
                  ))}
                </motion.ul>
              ) : (
                <p className="relative mt-6 rounded-2xl border border-dashed border-white/10 px-5 py-8 text-center text-sm text-white/35">
                  Rosa in fase di definizione.
                </p>
              )}

              <p className="relative mt-6 flex items-start gap-2.5 text-xs leading-relaxed text-white/35">
                <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-toad/60" />
                Massimo 8 giocatori per team. I giocatori si prendono prima dei
                tornei e non durante: chi è indietro ha priorità sugli acquisti.
              </p>
            </motion.div>
          </AnimatePresence>
        </div>
      </div>
    </section>
  );
}
