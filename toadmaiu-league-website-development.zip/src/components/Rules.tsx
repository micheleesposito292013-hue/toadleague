import { motion } from "framer-motion";
import {
  ArrowLeftRight,
  Gamepad2,
  Gift,
  ShieldAlert,
  ScrollText,
  Sparkles,
  Users,
  type LucideIcon,
} from "lucide-react";
import { RULES, type RuleKind } from "../data/league";

const ICONS: Record<RuleKind, LucideIcon> = {
  points: Gamepad2,
  teams: Users,
  market: ArrowLeftRight,
  special: Sparkles,
  conduct: ShieldAlert,
  prizes: Gift,
};

function CardChips() {
  return (
    <div className="mt-6 flex flex-wrap gap-2.5 border-t border-white/5 pt-5">
      <span className="flex items-center gap-2.5 rounded-xl border border-amber-400/25 bg-amber-400/8 px-3.5 py-2 text-xs font-semibold text-amber-300">
        <span className="h-4 w-3 rounded-[3px] bg-amber-400" />
        Giallo · richiamato
      </span>
      <span className="flex items-center gap-2.5 rounded-xl border border-red-500/25 bg-red-500/8 px-3.5 py-2 text-xs font-semibold text-red-400">
        <span className="h-4 w-3 rounded-[3px] bg-red-500" />
        Rosso · espulso, fermo un torneo
      </span>
    </div>
  );
}

export default function Rules() {
  return (
    <section id="regolamento" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 bottom-0 h-[380px] w-[380px] rounded-full bg-toad/5 blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-14 flex flex-col gap-6 md:flex-row md:items-end md:justify-between"
        >
          <div>
            <p className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-toad">
              <span className="h-px w-10 bg-toad/60" />
              <ScrollText className="h-4 w-4" />
              Regole della casa
            </p>
            <h2 className="mt-4 font-display text-4xl font-black uppercase leading-none tracking-tight sm:text-6xl">
              Regolamento
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-white/40">
            Poche, chiare e non si negoziano. Le decisioni al limite vengono
            prese da Toadmaiu sul momento.
          </p>
        </motion.div>

        <div className="grid gap-5 md:grid-cols-2 lg:grid-cols-3">
          {RULES.map((r, i) => {
            const Icon = ICONS[r.kind];
            return (
              <motion.article
                key={r.kind}
                initial={{ opacity: 0, y: 40 }}
                whileInView={{ opacity: 1, y: 0 }}
                viewport={{ once: true, margin: "-60px" }}
                transition={{
                  delay: (i % 3) * 0.1,
                  duration: 0.8,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className="group flex flex-col rounded-3xl border border-white/8 bg-white/[0.02] p-7 transition-all duration-500 hover:border-toad/25 hover:bg-white/[0.035] sm:p-8"
              >
                <div className="flex items-center justify-between">
                  <div className="flex h-12 w-12 items-center justify-center rounded-xl border border-toad/20 bg-toad/8 transition-all duration-500 group-hover:bg-toad/15">
                    <Icon className="h-5 w-5 text-toad" strokeWidth={1.8} />
                  </div>
                  <p className="text-[10px] font-bold uppercase tracking-[0.22em] text-white/25">
                    {String(i + 1).padStart(2, "0")}
                  </p>
                </div>

                <h3 className="mt-6 font-display text-base font-bold uppercase tracking-wide text-mist">
                  {r.title}
                </h3>
                <p className="mt-1 text-[11px] font-medium uppercase tracking-[0.18em] text-toad/70">
                  {r.tagline}
                </p>

                <ul className="mt-5 flex flex-col gap-3.5">
                  {r.items.map((item) => (
                    <li key={item} className="flex gap-3">
                      <span className="mt-[7px] h-1.5 w-1.5 shrink-0 rotate-45 bg-toad/60" />
                      <span className="text-[13px] leading-relaxed text-white/50">
                        {item}
                      </span>
                    </li>
                  ))}
                </ul>

                {r.kind === "conduct" && <CardChips />}
              </motion.article>
            );
          })}
        </div>
      </div>
    </section>
  );
}
