import { motion } from "framer-motion";
import {
  ArrowDown,
  ArrowRight,
  CalendarDays,
  Crown,
  Globe,
  Layers,
  Trophy,
  Users,
} from "lucide-react";
import mascot from "../assets/toad-mascot.png";
import { SEASON } from "../data/league";

const STATS = [
  { icon: Users, value: "6", label: "Team in lizza" },
  { icon: Users, value: "8", label: "Max per team" },
  { icon: Trophy, value: "4", label: "Posti Coppa" },
  { icon: Layers, value: "3", label: "Tier di giochi" },
];

const container = {
  hidden: {},
  show: { transition: { staggerChildren: 0.12, delayChildren: 0.15 } },
};

const item = {
  hidden: { opacity: 0, y: 36 },
  show: {
    opacity: 1,
    y: 0,
    transition: { duration: 0.9, ease: [0.22, 1, 0.36, 1] as const },
  },
};

export default function Hero() {
  return (
    <section id="top" className="grid-bg relative overflow-hidden">
      {/* glow */}
      <div className="pointer-events-none absolute -top-48 left-1/2 h-[560px] w-[880px] -translate-x-1/2 rounded-full bg-toad/10 blur-[150px]" />
      <div className="pointer-events-none absolute -bottom-32 -right-24 h-[420px] w-[520px] rounded-full bg-violet-500/10 blur-[140px]" />
      {/* grid fade */}
      <div className="pointer-events-none absolute inset-x-0 bottom-0 h-48 bg-gradient-to-t from-void to-transparent" />

      <div className="relative mx-auto grid max-w-7xl items-center gap-14 px-6 pb-20 pt-36 lg:grid-cols-[1.05fr_0.95fr] lg:gap-8 lg:pb-28 lg:pt-44">
        {/* Copy */}
        <motion.div variants={container} initial="hidden" animate="show">
          <motion.div
            variants={item}
            className="inline-flex items-center gap-2.5 rounded-full border border-toad/25 bg-toad/5 px-4 py-2"
          >
            <CalendarDays className="h-3.5 w-3.5 text-toad" />
            <span className="text-[11px] font-semibold uppercase tracking-[0.22em] text-toad">
              Season {SEASON.number} · {SEASON.start} → {SEASON.end}
            </span>
          </motion.div>

          <motion.h1
            variants={item}
            className="mt-7 font-display text-[clamp(2.6rem,7.2vw,5.6rem)] font-black uppercase leading-[0.95] tracking-tight"
          >
            Toadmaiu
            <span className="text-outline-toad block">League</span>
          </motion.h1>

          <motion.p
            variants={item}
            className="mt-7 max-w-xl text-base leading-relaxed text-white/55 sm:text-lg"
          >
            La competizione ufficiale del canale di{" "}
            <span className="font-semibold text-mist">Samuele Maiuri</span> —
            in arte <span className="font-semibold text-toad">Toadmaiu</span>.
            Sei team, tornei in live su Fortnite, Rocket League, Brawl Stars e
            non solo. Un solo trono: chi lo prende, se lo tiene.
          </motion.p>

          <motion.div variants={item} className="mt-10 flex flex-wrap gap-4">
            <a
              href="#classifica"
              className="group inline-flex items-center gap-3 rounded-full bg-toad px-7 py-3.5 text-[13px] font-bold uppercase tracking-[0.14em] text-void transition-all duration-300 hover:shadow-[0_0_40px_rgba(163,230,53,0.5)]"
            >
              Vedi la classifica
              <ArrowRight className="h-4 w-4 transition-transform duration-300 group-hover:translate-x-1" />
            </a>
            <a
              href="#regolamento"
              className="inline-flex items-center gap-3 rounded-full border border-white/15 px-7 py-3.5 text-[13px] font-bold uppercase tracking-[0.14em] text-mist transition-all duration-300 hover:border-toad/50 hover:text-toad"
            >
              Regolamento
            </a>
          </motion.div>

          <motion.a
            variants={item}
            href="https://toadmaiuleague.com"
            target="_blank"
            rel="noopener noreferrer"
            className="mt-6 inline-flex items-center gap-2 text-xs font-medium tracking-wide text-white/35 transition-colors hover:text-toad"
          >
            <Globe className="h-3.5 w-3.5" />
            Sito ufficiale: toadmaiuleague.com
          </motion.a>

          <motion.dl
            variants={item}
            className="mt-14 grid grid-cols-2 gap-x-6 gap-y-8 border-t border-white/8 pt-8 sm:grid-cols-4"
          >
            {STATS.map((s) => (
              <div key={s.label}>
                <s.icon className="h-4 w-4 text-toad/70" />
                <dt className="sr-only">{s.label}</dt>
                <dd className="mt-2 font-display text-3xl font-bold text-mist">
                  {s.value}
                </dd>
                <dd className="mt-1 text-[11px] font-medium uppercase tracking-[0.16em] text-white/35">
                  {s.label}
                </dd>
              </div>
            ))}
          </motion.dl>
        </motion.div>

        {/* Mascot */}
        <motion.div
          initial={{ opacity: 0, scale: 0.92, y: 24 }}
          animate={{ opacity: 1, scale: 1, y: 0 }}
          transition={{ duration: 1.1, delay: 0.35, ease: [0.22, 1, 0.36, 1] }}
          className="relative mx-auto w-full max-w-md lg:max-w-none"
        >
          <div className="animate-pulse-glow absolute inset-8 rounded-full bg-toad/20 blur-[90px]" />

          <div className="relative overflow-hidden rounded-[2.5rem] border border-white/10 shadow-[0_40px_120px_-30px_rgba(0,0,0,0.9)]">
            <img
              src={mascot}
              alt="Mascotte Toadmaiu League"
              className="h-full w-full object-cover"
            />
            <div className="absolute inset-0 bg-gradient-to-t from-void/50 via-transparent to-transparent" />
          </div>

          {/* floating chips */}
          <div className="animate-float absolute -left-4 top-8 hidden items-center gap-2.5 rounded-2xl border border-white/10 bg-panel/90 px-4 py-3 backdrop-blur-md sm:flex">
            <Trophy className="h-4 w-4 text-toad" />
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-toad">
                Top 4
              </p>
              <p className="text-[11px] font-medium text-white/60">
                Volano in Coppa
              </p>
            </div>
          </div>

          <div className="animate-float-slow absolute -right-3 bottom-10 hidden items-center gap-2.5 rounded-2xl border border-toad/25 bg-toad/10 px-4 py-3 backdrop-blur-md sm:flex">
            <Crown className="h-4 w-4 text-yellow-300" />
            <div>
              <p className="text-[10px] font-bold uppercase tracking-[0.18em] text-toad">
                Leader
              </p>
              <p className="text-[11px] font-medium text-white/60">
                Frog Slayers · 43 pt
              </p>
            </div>
          </div>
        </motion.div>
      </div>

      {/* scroll cue */}
      <motion.a
        href="#classifica"
        initial={{ opacity: 0 }}
        animate={{ opacity: 1 }}
        transition={{ delay: 1.4, duration: 1 }}
        className="absolute bottom-6 left-1/2 hidden -translate-x-1/2 flex-col items-center gap-2 text-white/30 transition-colors hover:text-toad lg:flex"
      >
        <span className="text-[10px] font-semibold uppercase tracking-[0.3em]">
          Scorri
        </span>
        <ArrowDown className="h-4 w-4 animate-bounce" />
      </motion.a>
    </section>
  );
}
