import { motion } from "framer-motion";
import { CalendarClock, Trophy, Users } from "lucide-react";
import { STANDINGS } from "../data/league";

const HIGHLIGHTS = [
  { icon: Trophy, title: "Mini campionato", desc: "Le prime 4 si sfidano tra loro" },
  { icon: CalendarClock, title: "Una settimana", desc: "Durata complessiva della Coppa" },
  { icon: Users, title: "Max 5 a team", desc: "Roster ridotti per la Coppa" },
];

export default function Cup() {
  const qualified = STANDINGS.filter((s) => s.cup);

  return (
    <section id="coppa" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute right-0 top-0 h-[380px] w-[380px] rounded-full bg-violet-500/8 blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-6">
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="rounded-[2.5rem] bg-gradient-to-br from-toad/35 via-white/10 to-transparent p-px"
        >
          <div className="relative overflow-hidden rounded-[calc(2.5rem-1px)] bg-panel px-7 py-12 sm:px-12 sm:py-16">
            <div className="pointer-events-none absolute -right-24 -top-24 h-72 w-72 rounded-full bg-toad/10 blur-[100px]" />

            <div className="relative grid gap-12 lg:grid-cols-[0.9fr_1.1fr] lg:items-center">
              {/* left */}
              <div>
                <div className="flex h-16 w-16 items-center justify-center rounded-2xl border border-toad/25 bg-toad/10">
                  <Trophy className="h-8 w-8 text-toad" strokeWidth={1.6} />
                </div>
                <h2 className="mt-8 font-display text-4xl font-black uppercase leading-none tracking-tight sm:text-5xl">
                  La <span className="text-toad">Coppa</span>
                </h2>
                <p className="mt-6 max-w-md text-sm leading-relaxed text-white/50 sm:text-base">
                  Le prime 4 della classifica si qualificano alla Coppa: un mini
                  campionato tra le quattro squadre che dura una settimana, con
                  un massimo di{" "}
                  <span className="font-semibold text-mist">
                    5 giocatori a team
                  </span>
                  . I fondatori possono partecipare dove preferiscono, se hanno
                  due team.
                </p>

                <div className="mt-8 flex flex-wrap gap-3">
                  {qualified.map((s) => (
                    <span
                      key={s.team}
                      className="inline-flex items-center gap-3 rounded-2xl border border-white/10 bg-white/[0.04] px-4 py-2.5 text-xs font-semibold text-mist"
                    >
                      <img
                        src={s.badge}
                        alt={s.team}
                        className="h-7 w-7 rounded-md object-contain"
                      />
                      <span className="font-display text-toad">{s.rank}</span>
                      {s.team}
                    </span>
                  ))}
                </div>
              </div>

              {/* right */}
              <div className="grid gap-4 sm:grid-cols-3 lg:grid-cols-1 xl:grid-cols-3">
                {HIGHLIGHTS.map((h, i) => (
                  <motion.div
                    key={h.title}
                    initial={{ opacity: 0, y: 24 }}
                    whileInView={{ opacity: 1, y: 0 }}
                    viewport={{ once: true }}
                    transition={{
                      delay: 0.2 + i * 0.1,
                      duration: 0.6,
                      ease: [0.22, 1, 0.36, 1],
                    }}
                    className="rounded-2xl border border-white/8 bg-white/[0.03] p-5"
                  >
                    <h.icon className="h-5 w-5 text-toad" strokeWidth={1.8} />
                    <p className="mt-4 font-display text-[13px] font-bold uppercase tracking-wide text-mist">
                      {h.title}
                    </p>
                    <p className="mt-1.5 text-xs leading-relaxed text-white/40">
                      {h.desc}
                    </p>
                  </motion.div>
                ))}
              </div>
            </div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
