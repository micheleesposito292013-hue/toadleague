import { Sparkles } from "lucide-react";

const GAMES = [
  "Rocket League",
  "Brawl Stars",
  "Fortnite",
  "Gartic Phone",
  "Kukoro",
  "Skribbl",
  "Gartic Show",
  "Minecraft",
  "Stumble Guys",
  "Fall Guys",
];

export default function Marquee() {
  const row = [...GAMES, ...GAMES];
  return (
    <div className="relative overflow-hidden py-6">
      <div className="-mx-2 -rotate-1 border-y border-void/40 bg-toad py-4 shadow-[0_0_80px_rgba(163,230,53,0.22)]">
        <div className="animate-marquee flex w-max items-center gap-10 whitespace-nowrap pr-10">
          {row.map((g, i) => (
            <span
              key={i}
              className="flex items-center gap-10 font-display text-[13px] font-bold uppercase tracking-[0.2em] text-void"
            >
              {g}
              <Sparkles className="h-4 w-4" strokeWidth={2.5} />
            </span>
          ))}
        </div>
      </div>
    </div>
  );
}
