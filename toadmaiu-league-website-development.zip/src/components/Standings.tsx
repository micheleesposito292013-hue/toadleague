import { motion } from "framer-motion";
import { Info, Medal, Trophy } from "lucide-react";
import { SEASON, STANDINGS, ZONES } from "../data/league";

const MEDAL_COLOR: Record<number, string> = {
  1: "text-yellow-300",
  2: "text-neutral-300",
  3: "text-amber-500",
};

export default function Standings() {
  return (
    <section id="classifica" className="relative py-24 sm:py-32">
      <div className="pointer-events-none absolute left-0 top-1/3 h-[420px] w-[420px] rounded-full bg-toad/5 blur-[130px]" />

      <div className="relative mx-auto max-w-7xl px-6">
        {/* header */}
        <motion.div
          initial={{ opacity: 0, y: 32 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-80px" }}
          transition={{ duration: 0.8, ease: [0.22, 1, 0.36, 1] }}
          className="mb-14 flex flex-col gap-6 md:flex-row md:items-end md:justify-between"
        >
          <div>
            <p className="flex items-center gap-3 text-[11px] font-bold uppercase tracking-[0.3em] text-toad">
              <span className="h-px w-10 bg-toad/60" />
              Season {SEASON.number} · {SEASON.start} → {SEASON.end}
            </p>
            <h2 className="mt-4 font-display text-4xl font-black uppercase leading-none tracking-tight sm:text-6xl">
              Classifica
            </h2>
          </div>
          <p className="max-w-sm text-sm leading-relaxed text-white/40">
            Aggiornata a ogni torneo. Le prime quattro volano dritte in{" "}
            <a href="#coppa" className="text-toad underline decoration-toad/40 underline-offset-4 hover:decoration-toad">
              Coppa
            </a>
            .
          </p>
        </motion.div>

        {/* table */}
        <motion.div
          initial={{ opacity: 0, y: 40 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true, margin: "-60px" }}
          transition={{ duration: 0.9, ease: [0.22, 1, 0.36, 1] }}
          className="overflow-hidden rounded-3xl border border-white/10 bg-panel/60 backdrop-blur-sm"
        >
          {STANDINGS.map((s, i) => {
            const zone = ZONES[s.zone];
            return (
              <motion.div
                key={s.team}
                initial={{ opacity: 0, x: -28 }}
                whileInView={{ opacity: 1, x: 0 }}
                viewport={{ once: true, margin: "-40px" }}
                transition={{
                  delay: i * 0.07,
                  duration: 0.6,
                  ease: [0.22, 1, 0.36, 1],
                }}
                className={`group relative grid grid-cols-[52px_40px_1fr_auto] items-center gap-3 px-4 py-5 transition-colors duration-300 hover:bg-white/[0.03] sm:grid-cols-[72px_52px_1fr_auto] sm:gap-5 sm:px-7 ${
                  i > 0 ? "border-t border-white/5" : ""
                } ${
                  s.rank === 1
                    ? "bg-gradient-to-r from-toad/[0.09] via-transparent to-transparent"
                    : ""
                }`}
              >
                {/* rank */}
                <div className="flex items-center gap-3">
                  <span
                    className={`font-display text-2xl font-extrabold tabular-nums sm:text-3xl ${
                      s.rank === 1 ? "text-toad" : "text-white/25"
                    }`}
                  >
                    {s.rank}
                  </span>
                  {MEDAL_COLOR[s.rank] && (
                    <Medal
                      className={`h-5 w-5 ${MEDAL_COLOR[s.rank]}`}
                      strokeWidth={1.8}
                    />
                  )}
                </div>

                {/* badge */}
                <div className="flex items-center justify-center">
                  <img
                    src={s.badge}
                    alt={`${s.team} badge`}
                    className="h-10 w-10 rounded-lg object-contain sm:h-[52px] sm:w-[52px]"
                  />
                </div>

                {/* team */}
                <div className="flex min-w-0 items-center gap-3 sm:gap-4">
                  <span
                    className={`h-2.5 w-2.5 shrink-0 rounded-full ${zone.dot} ${zone.glow}`}
                    title={zone.label}
                  />
                  <div className="min-w-0">
                    <p className="truncate font-display text-sm font-bold uppercase tracking-wide text-mist sm:text-base">
                      {s.team}
                    </p>
                    <div className="mt-1 flex items-center gap-2">
                      <p className="text-[10px] font-medium uppercase tracking-[0.16em] text-white/30">
                        {zone.label}
                      </p>
                      {s.cup && (
                        <span className="inline-flex items-center gap-1 rounded-full border border-toad/30 bg-toad/10 px-2 py-0.5 text-[9px] font-bold uppercase tracking-[0.14em] text-toad">
                          <Trophy className="h-2.5 w-2.5" />
                          Coppa
                        </span>
                      )}
                    </div>
                  </div>
                </div>

                {/* points */}
                <div className="text-right">
                  <span
                    className={`font-display text-2xl font-extrabold tabular-nums sm:text-4xl ${
                      s.rank === 1 ? "text-toad" : "text-mist"
                    }`}
                  >
                    {s.points}
                  </span>
                  <span className="ml-1.5 text-[10px] font-bold uppercase tracking-[0.2em] text-white/30">
                    pt
                  </span>
                </div>
              </motion.div>
            );
          })}
        </motion.div>

        {/* no-scores note */}
        <motion.p
          initial={{ opacity: 0 }}
          whileInView={{ opacity: 1 }}
          viewport={{ once: true }}
          transition={{ delay: 0.4, duration: 0.8 }}
          className="mt-5 flex items-start gap-2.5 text-xs leading-relaxed text-white/35"
        >
          <Info className="mt-0.5 h-3.5 w-3.5 shrink-0 text-toad/60" />
          Niente punteggi partita per partita, niente differenza reti: in questa
          classifica contano solo i punti conquistati nei tornei della season.
        </motion.p>

        {/* zone legend */}
        <div className="mt-12 grid grid-cols-1 gap-3 sm:grid-cols-2 lg:grid-cols-5">
          {Object.entries(ZONES).map(([key, z], i) => (
            <motion.div
              key={key}
              initial={{ opacity: 0, y: 24 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true, margin: "-40px" }}
              transition={{
                delay: i * 0.06,
                duration: 0.6,
                ease: [0.22, 1, 0.36, 1],
              }}
              className="rounded-2xl border border-white/5 bg-white/[0.02] p-4 transition-colors duration-300 hover:border-white/15"
            >
              <div className="flex items-center gap-2.5">
                <span
                  className={`h-2.5 w-2.5 rounded-full ${z.dot} ${z.glow}`}
                />
                <p className="text-[13px] font-semibold text-mist">{z.label}</p>
              </div>
              <p className="mt-1.5 text-[11px] leading-relaxed text-white/35">
                {z.desc}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
