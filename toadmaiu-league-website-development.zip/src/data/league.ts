import badgeFrogSlayers from "../assets/badge-frog-slayers.png";
import badgeSportingMaiuri from "../assets/badge-sporting-maiuri.png";
import badgeRealeMaiuri from "../assets/badge-reale-maiuri.png";
import badgeOmegaBears from "../assets/badge-omega-bears.png";
import badgeAcTuax from "../assets/badge-ac-tuax.png";
import badgeAcVostra from "../assets/badge-ac-vostra.png";

export type ZoneKey = "green" | "blue" | "white" | "yellow" | "red";

export interface Standing {
  rank: number;
  team: string;
  points: number;
  zone: ZoneKey;
  cup: boolean;
  badge: string;
}

export const BADGES: Record<string, string> = {
  "Frog Slayers": badgeFrogSlayers,
  "Sporting Maiuri": badgeSportingMaiuri,
  "Reale Maiuri": badgeRealeMaiuri,
  "Omega Bears": badgeOmegaBears,
  "Ac Tuax": badgeAcTuax,
  "Ac Vostra": badgeAcVostra,
};

export const SEASON = {
  number: 4,
  start: "01/10/2026",
  end: "10/12/2026",
};

export const STANDINGS: Standing[] = [
  { rank: 1, team: "Frog Slayers", points: 43, zone: "green", cup: true, badge: badgeFrogSlayers },
  { rank: 2, team: "Sporting Maiuri", points: 42, zone: "blue", cup: true, badge: badgeSportingMaiuri },
  { rank: 3, team: "Reale Maiuri", points: 41, zone: "white", cup: true, badge: badgeRealeMaiuri },
  { rank: 4, team: "Omega Bears", points: 39, zone: "white", cup: true, badge: badgeOmegaBears },
  { rank: 5, team: "Ac Tuax", points: 38, zone: "white", cup: false, badge: badgeAcTuax },
  { rank: 6, team: "Ac Vostra", points: 35, zone: "yellow", cup: false, badge: badgeAcVostra },
];

export const ROSTERS: Record<string, string[]> = {
  "Frog Slayers": [
    "Luca",
    "Wossito",
    "Luigi Confort",
    "Mattex",
    "Francy",
    "Springtrap",
    "Brigata-decente fili",
  ],
  "Sporting Maiuri": [
    "toadmaiu",
    "azzurra",
    "rereyu",
    "March3zz",
    "ttm_onyt",
    "atlossl_bonsi",
    "sadin",
  ],
  "Reale Maiuri": [
    "Vivolupo",
    "Hackers",
    "Filippo Menegoni",
    "Steal",
    "Tekaaaa",
    "Mattia_Bonsi",
    "IlGiuse",
  ],
  "Omega Bears": [
    "Super Luchino",
    "Ponchione",
    "Squishy",
    "Dreonaprime",
    "Pipobex",
    "Tille_Pro",
    "ilovelollolacustre2",
  ],
  "Ac Tuax": [
    "Ragazzo Stabiese",
    "Giox",
    "Nezuko",
    "Hukker",
    "Wave",
    "Davax",
    "Enlure",
  ],
  "Ac Vostra": [
    "Bizioo",
    "Erpollo",
    "alfgigi",
    "GP1_Cri",
    "niicoox9",
    "Chrys-_-Prays",
    "Bruno",
  ],
};

export const ZONES: Record<
  ZoneKey,
  { dot: string; glow: string; label: string; desc: string }
> = {
  green: {
    dot: "bg-emerald-400",
    glow: "shadow-[0_0_14px_rgba(52,211,153,0.9)]",
    label: "Vittoria campionato",
    desc: "Bonus assicurati per il campione.",
  },
  blue: {
    dot: "bg-sky-400",
    glow: "shadow-[0_0_14px_rgba(56,189,248,0.9)]",
    label: "Premi bonus",
    desc: "Probabili, ma non ufficiali.",
  },
  white: {
    dot: "bg-neutral-200",
    glow: "shadow-[0_0_14px_rgba(229,229,229,0.7)]",
    label: "Rimangono",
    desc: "Restano in League, senza premi extra.",
  },
  yellow: {
    dot: "bg-amber-400",
    glow: "shadow-[0_0_14px_rgba(251,191,36,0.9)]",
    label: "Attenzione",
    desc: "Possibile esclusione se i punti sono pochi.",
  },
  red: {
    dot: "bg-red-500",
    glow: "shadow-[0_0_14px_rgba(239,68,68,0.9)]",
    label: "Retrocessione",
    desc: "Esclusione dal prossimo campionato più probabile.",
  },
};

export const TIERS = [
  {
    rank: "01",
    name: "Main Event",
    badge: "Principali",
    games: ["Rocket League", "Brawl Stars"],
    note: "I due titoli principali della League: qui si fanno i punti più importanti.",
    featured: true,
  },
  {
    rank: "02",
    name: "Secondo Posto",
    badge: "Secondari",
    games: ["Fortnite", "Gartic Phone", "Kukoro", "Skribbl", "Gartic Show"],
    note: "Fortnite e tutti i giochi interattivi del canale.",
    featured: false,
  },
  {
    rank: "03",
    name: "Terzo Posto",
    badge: "Terzi",
    games: ["Minecraft", "Stumble Guys", "Fall Guys"],
    note: "Il terzo gruppo di titoli validi per i tornei.",
    featured: false,
  },
];

export type RuleKind =
  | "points"
  | "teams"
  | "market"
  | "special"
  | "conduct"
  | "prizes";

export interface RuleSection {
  kind: RuleKind;
  title: string;
  tagline: string;
  items: string[];
}

export const RULES: RuleSection[] = [
  {
    kind: "points",
    title: "Punti & Tornei",
    tagline: "Come si scala la classifica",
    items: [
      "Per fare punti devi partecipare ai tornei del canale: Fortnite, Rocket League, Brawl Stars e giochi interattivi.",
      "In alcuni tornei vale anche il secondo posto.",
      "I punti vengono sempre decisi prima del torneo.",
      "I giocatori si prendono prima dei tornei e non durante: chi rimane indietro, o ha gente offline, parte con vantaggi.",
    ],
  },
  {
    kind: "teams",
    title: "Team & Capitani",
    tagline: "Chi comanda in campo",
    items: [
      "Ogni team è composto da un capitano, che deve creare la squadra: massimo 8 giocatori.",
      "Oltre ai premi, i team si affrontano nei tornei delle live — valgono tutti i giochi.",
      "Se un capitano non può venire, la squadra viene aiutata.",
    ],
  },
  {
    kind: "market",
    title: "Mercato & Scambi",
    tagline: "Calciomercato della League",
    items: [
      "I giocatori si possono scambiare e svincolare solo su accordo: il giocatore deve essere d'accordo con tutto.",
      "Puoi prendere i giocatori liberi che vuoi, se non sono troppo sgravati in quel gioco. Altrimenti: penalità ad hoc, oppure il giocatore farà punti sugli altri giochi ma non sul suo.",
      "Chi rimane indietro ha la priorità sui nuovi acquisti rispetto a chi va avanti — e verrà aiutato. Slot pieni non vale, espellere gente come tattica non vale, non sgravare.",
      "Gli scambi devono avere senso, sennò sono annullati.",
    ],
  },
  {
    kind: "special",
    title: "Jolly & Wild Card",
    tagline: "Le carte speciali",
    items: [
      "Jolly: vengono decisi sul momento per i giocatori troppo forti nel rispettivo gioco.",
      "Wild Card: chi riceve un torto arbitrale può ottenere una carta che garantisce permessi speciali, decisi sul momento.",
      "La Wild Card vale solo per la season corrente.",
    ],
  },
  {
    kind: "conduct",
    title: "Condotta & Cartellini",
    tagline: "Fair play obbligatorio",
    items: [
      "In game ci si affronta anche tra alleati: vietato teammare e sabotare lo streamer.",
      "Chi tenta di sabotare la Toadmaiu League o si fa corrompere rischia espulsione o sospensione — con conseguenze anche nel canale.",
      "Per le infrazioni più gravi è previsto togliere punti.",
    ],
  },
  {
    kind: "prizes",
    title: "Premi",
    tagline: "Cosa c'è in palio",
    items: [
      "Durante la season sono previsti premi bonus.",
      "Al capitano spettano premi e il ruolo di capomod.",
      "Vincere il campionato significa bonus assicurati.",
      "Premi extra per chi finisce nelle zone alte: probabili, ma non ufficiali.",
    ],
  },
];
